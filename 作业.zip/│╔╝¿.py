#!/usr/bin/env python
# coding: utf-8
import numpy as np
import pandas as pd
from pandas import DataFrame
hero=pd.read_excel(r'C:\Users\HP\Desktop\班级英雄成绩表.xlsx')
print(hero)

for str in hero.columns[1:4]:
    print(str+"平均成绩",np.mean(hero[str]))
for str in hero.columns[1:4]:
    print(str+"最高成绩",np.max(hero[str]))
for str in hero.columns[1:4]:
    print(str+"最低成绩",np.min(hero[str]))
for str in hero.columns[1:4]:
    print(str+"成绩方差",np.var(hero[str]))
for str in hero.columns[1:4]:
    print(str+"成绩标准差",np.std(hero[str]))
#利用for语言实现打印每个结果，后者也可采用添加至列的形式


# In[52]:


hero['总成绩']=hero['语文']+hero['数学']+hero['英语']
#添加一列总成绩
print(hero)

hero_mingci=hero.sort_values(by='总成绩',ascending=False)
print(hero_mingci)
#从高到低排序
