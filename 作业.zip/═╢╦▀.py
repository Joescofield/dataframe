#!/usr/bin/env python
# coding: utf-8

# In[28]:


import numpy as np
import pandas as pd
data=pd.read_csv(r'C:\Users\HP\Desktop\car_complain.csv')
data
#数据导入


# In[29]:


new_data=data.drop('problem',axis=1).join(data.problem.str.get_dummies(','))
new_data
#拆分多列


# In[39]:


result=new_data.groupby(['brand'])['desc'].agg(['count'])
result
#投诉总计
new_data.columns
types=new_data.columns[8:]
types
#查看问题类型排序并赋值
result_problem=new_data.groupby(['brand'])[types].agg(['sum'])
result_problem
#利用groupby进行分组统计

