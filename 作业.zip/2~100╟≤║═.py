#!/usr/bin/env python
# coding: utf-8

# In[1]:


s=0
for i in range(2,101,2):
    s+=i
print(s)


# In[3]:


import numpy as np
sum(np.arange(2,101,2))


# In[ ]:




